import java.util.*;
public class helloworld{
	public static void main(String[] args){
		System.out.println("Hello World\n");
	}

	//use for junit test
	String str;
	public void hello(){
		str="Hello World!";
	}
	public String getStr(){
		return str;
	}
}